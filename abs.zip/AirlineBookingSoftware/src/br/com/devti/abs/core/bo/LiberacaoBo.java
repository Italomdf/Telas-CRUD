package br.com.devti.abs.core.bo;

public class LiberacaoBo {

}
