package br.com.devti.abs.core.entity;

import java.util.Objects;

public class PassageiroEntity extends UsuarioEntity{
	
	private String cpf;
	private int idade;
	
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(cpf);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PassageiroEntity other = (PassageiroEntity) obj;
		return Objects.equals(cpf, other.cpf);
	}
	
	

}
