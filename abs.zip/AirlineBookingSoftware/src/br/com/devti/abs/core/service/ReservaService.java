package br.com.devti.abs.core.service;

public class ReservaService {

}
