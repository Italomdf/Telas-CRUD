package br.com.devti.abs.core.dao;

public class LiberacaoDao {

}
