package br.com.devti.abs.core.entity;

public class EmpresaAereaEntity extends UsuarioEntity{

}
