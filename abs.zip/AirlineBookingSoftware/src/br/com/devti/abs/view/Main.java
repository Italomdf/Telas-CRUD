package br.com.devti.abs.view;

import java.util.List;

import javax.swing.JOptionPane;

import br.com.devti.abs.core.entity.AviaoEntity;
import br.com.devti.abs.core.entity.UsuarioEntity;
import br.com.devti.abs.core.service.AviaoService;
import br.com.devti.abs.core.service.UsuarioService;
import br.com.devti.abs.core.util.exception.NegocioException;

public class Main {

	public static void main(String[] args){
		
		
//		UsuarioEntity usuario = new UsuarioEntity();
//		usuario.setNome("Ítalo");
//		usuario.setLogin("Italodf");
//		usuario.setSenha("123456");
//		usuario.setEmail("italodefaveri@gmail.com");
//		
//		UsuarioService us = new UsuarioService();
//			
//		try {
//			System.out.println(us.salvarUsuario(usuario));
////		} catch (NegocioException e) {
////			JOptionPane.showMessageDialog(null, e.getMensagemDeErro());
////		}
//	
//		
//		try {
//			new UsuarioService().excluirUsuario(10L);
//		} catch (NegocioException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//
//	List<UsuarioEntity> usuarios;
//	try {
//		usuarios = new UsuarioService().listarUsuario();
//		for (UsuarioEntity usuarioEntity : usuarios) {
//			System.out.println("Nome: " + usuarioEntity.getNome() + " - Código " + usuarioEntity.getCodigo());
//		}
//	} catch (NegocioException e) {
//		e.printStackTrace();
//	}
//	
//		
//	try {
//		UsuarioEntity usuarioEncontrado = new UsuarioService().buscarUsuarioPorId(11L);
//		if(usuarioEncontrado == null) {
//			JOptionPane.showMessageDialog(null, "Nao encontrou o usuario");
//		}else {
//		JOptionPane.showMessageDialog(null, "O usuario encontrado foi: " + usuarioEncontrado.getNome());
//		}
//	} catch (NegocioException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	
//	UsuarioEntity usuario = new UsuarioEntity();
//	usuario.setCodigo(12L);
//	usuario.setNome("Ítaloalterado");
//	usuario.setLogin("Italodf");
//	usuario.setSenha("123456");
//	usuario.setEmail("italodefaveri@gmail.com");
//	
//	try {
//		JOptionPane.showMessageDialog(null, new UsuarioService().alterarUsuario(usuario));
//	} catch (NegocioException e) {
//
//		e.printStackTrace();
//	}
		
		//Aviao
		
//		AviaoEntity aviao = new AviaoEntity();
//		aviao.setMarca("GOL");
//		aviao.setBase("santos");
//		aviao.setAnoFabricacao("2003");
//		
//		AviaoService as = new AviaoService();
//			
//		try {
//			System.out.println(as.salvarAviao(aviao));
//		} catch (NegocioException e) {
//			JOptionPane.showMessageDialog(null, e.getMensagemDeErro());
//		}
		
		
	
}
	
}

